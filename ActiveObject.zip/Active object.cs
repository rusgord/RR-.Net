﻿using System;
using System.Threading.Tasks;

namespace ActiveObject
{
    class Servant
    {
        public void Action()
        {
            Console.WriteLine("Слуга виконує дiю");
        }
    }

    class Scheduler
    {
        public void Enqueue(Action action)
        {
            Task.Run(action);
        }
    }

    class Proxy
    {
        private Scheduler scheduler;
        private Servant servant;

        public Proxy()
        {
            scheduler = new Scheduler();
            servant = new Servant();
        }

        public void Request()
        {
            scheduler.Enqueue(servant.Action);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Proxy proxy = new Proxy();
            proxy.Request();
            Console.WriteLine("Клiєнт продовжує виконання");
        }
    }
}
