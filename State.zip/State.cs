﻿namespace $safeitemname$
{
    class Context
    {
        private $safeitemname$ _state = null;

        public Context($safeitemname$ state)
        {
            this.TransitionTo(state);
        }

        public void TransitionTo($safeitemname$ state)
        {
            Console.WriteLine($"Контекст: Перехiд до {state.GetType().Name}.");
            this._state = state;
            this._state.SetContext(this);
        }

        public void Request1()
        {
            this._state.Handle1();
        }

        public void Request2()
        {
            this._state.Handle2();
        }
    }

    abstract class $safeitemname$
    {
        protected Context _context;

        public void SetContext(Context context)
        {
            this._context = context;
        }

        public abstract void Handle1();

        public abstract void Handle2();
    }

    class ConcreteStateA : $safeitemname$
    {
        public override void Handle1()
        {
            Console.WriteLine("ConcreteStateA обробляє запит1.");
            Console.WriteLine("ConcreteStateA хоче змiнити стан контексту.");
            this._context.TransitionTo(new ConcreteStateB());
        }

        public override void Handle2()
        {
            Console.WriteLine("ConcreteStateA обробляє запит2.");
        }
    }

    class ConcreteStateB : $safeitemname$
    {
        public override void Handle1()
        {
            Console.WriteLine("ConcreteStateB обробляє запит1.");
        }

        public override void Handle2()
        {
            Console.WriteLine("ConcreteStateB обробляє запит2.");
            Console.WriteLine("ConcreteStateB хоче змiнити стан контексту.");
            this._context.TransitionTo(new ConcreteStateA());
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var context = new Context(new ConcreteStateA());
            context.Request1();
            context.Request2();
        }
    }
}
