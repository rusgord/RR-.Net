﻿namespace FacadePattern
{
    class Subsystem1
    {
        public void Operation1()
        {
            Console.WriteLine("Пiдсистема 1 Операцiя 1");
        }
    }

    class Subsystem2
    {
        public void Operation2()
        {
            Console.WriteLine("Пiдсистема 2 Операцiя 2");
        }
    }

    class Subsystem3
    {
        public void Operation3()
        {
            Console.WriteLine("Пiдсистема 3 Операцiя 3");
        }
    }

    class $safeitemname$
    {
        private Subsystem1 subsystem1;
        private Subsystem2 subsystem2;
        private Subsystem3 subsystem3;

        public $safeitemname$()
        {
            subsystem1 = new Subsystem1();
            subsystem2 = new Subsystem2();
            subsystem3 = new Subsystem3();
        }

        public void Operation()
        {
            subsystem1.Operation1();
            subsystem2.Operation2();
            subsystem3.Operation3();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            $safeitemname$ facade = new $safeitemname$();
            facade.Operation();
        }
    }
}